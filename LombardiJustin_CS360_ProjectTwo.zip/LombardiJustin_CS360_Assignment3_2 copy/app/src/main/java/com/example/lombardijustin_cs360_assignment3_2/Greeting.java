package com.example.lombardijustin_cs360_assignment3_2;

public class Greeting {
}
